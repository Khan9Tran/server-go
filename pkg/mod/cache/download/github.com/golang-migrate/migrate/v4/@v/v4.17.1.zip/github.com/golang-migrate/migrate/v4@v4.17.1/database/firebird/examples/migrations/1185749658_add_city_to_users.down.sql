ALTER TABLE users DROP city;
